
const produtos = [
  {
    id: 1,
    nome: "Tênis 1",
    preco: 199.90,
    img: "../loja/imagens/tenis1.jpg",
    features: ["Confortável", "Leve", "Resistente"]
  },
  {
    id: 2,
    nome: "Tênis 2",
    preco: 219.90,
    img: "../loja/imagens/tenis2.jpg",
    features: ["Design moderno", "Amortecimento", "Durável"]
  },
  {
    id: 3,
    nome: "Tênis 3",
    preco: 179.90,
    img: "../loja/imagens/tenis3.jpg",
    features: ["Esportivo", "Respirável", "Antiderrapante"]
  },
  {
    id: 4,
    nome: "Tênis 4",
    preco: 189.90,
    img: "../loja/imagens/tenis4.jpg",
    features: ["Casual", "Estilo urbano", "Leve"]
  },
  {
    id: 5,
    nome: "Tênis 5",
    preco: 249.90,
    img: "../loja/imagens/tenis5.jpg",
    features: ["Alta performance", "Ventilado", "Solado flexível"]
  },
  {
    id: 6,
    nome: "Tênis 6",
    preco: 199.90,
    img: "../loja/imagens/tenis6.jpg",
    features: ["Casual e leve", "Estampa exclusiva", "Solado em borracha"]
  },
  {
    id: 7,
    nome: "Tênis 7",
    preco: 209.90,
    img: "../loja/imagens/tenis7.jpg",
    features: ["Design futurista", "Ajuste anatômico", "Estabilidade"]
  },
  {
    id: 8,
    nome: "Tênis 8",
    preco: 229.90,
    img: "../loja/imagens/tenis8.jpg",
    features: ["Para dia-dia", "Ultra leve", "Confortável"]
  },

  {
    id: 9,
    nome: "Tênis 9",
    preco: 239.90,
    img: "../loja/imagens/tenis9.jpg",
    features: ["Resistente à água", "Leveza extrema", "Design exclusivo"]
  },

  {
    id: 10,
    nome: "Tênis 10",
    preco: 259.90,
    img: "../loja/imagens/tenis10.jpg",
    features: ["Para dia-dia", "Super aderente", "Alta resistência"]
  },

  {
    id: 11,
    nome: "Tênis 11",
    preco: 249.90,
    img: "../loja/imagens/tenis11.jpg",
    features: ["Confortável", "Macio", "Atraente"]
  },

  {
    id: 12,
    nome: "Tênis 12",
    preco: 219.90,
    img: "../loja/imagens/tenis12.jpg",
    features: ["Estilos", "Moderno", "Resistente"]
  }
];

const container = document.getElementById("produtos-container");

produtos.forEach(produto => {
  const card = document.createElement("div");
  card.className = "card";
  card.innerHTML = `
    <img src="${produto.img}" alt="${produto.nome}">
    <h3>${produto.nome}</h3>
    <p>Preço: R$ ${produto.preco.toFixed(2)}</p>
    <p>Escolha o tamanho:</p>
    <select id="tamanho-${produto.id}">
      <option>37</option>
      <option>38</option>
      <option>39</option>
      <option>40</option>
    </select>
    <p>Escolha a cor:</p>
    <select id="cor-${produto.id}">
      <option>Preto</option>
      <option>Branco</option>
      <option>Azul</option>
    </select>
    <p>Quantidade:</p>
    <input id="qtd-${produto.id}" type="number" min="1" value="1">
    <button onclick="adicionarAoCarrinhoLoja(${produto.id})">Comprar</button>
  `;
  container.appendChild(card);
});

function adicionarAoCarrinhoLoja(id) {
  const produto = produtos.find(p => p.id === id);
  const tamanho = document.getElementById(`tamanho-${id}`).value;
  const cor = document.getElementById(`cor-${id}`).value;
  const quantidade = parseInt(document.getElementById(`qtd-${id}`).value, 10);

  const carrinho = JSON.parse(localStorage.getItem('carrinho')) || [];

  const produtoCarrinho = {
    id: produto.id,
    nome: produto.nome,
    preco: produto.preco,
    img: produto.img,
    descricao: produto.features.join(", "),
    tamanho,
    cor,
    quantidade
  };

  const existente = carrinho.find(p =>
    p.id === produtoCarrinho.id && p.tamanho === produtoCarrinho.tamanho && p.cor === produtoCarrinho.cor
  );

  let mensagem = '';

  if (existente) {
    existente.quantidade += produtoCarrinho.quantidade;
    mensagem = `${produtoCarrinho.nome} (+${produtoCarrinho.quantidade} und.) já está no carrinho.`;
  } else {
    carrinho.push(produtoCarrinho);
    mensagem = `${produtoCarrinho.nome} (${produtoCarrinho.quantidade} und.) foi adicionado ao carrinho.`;
  }

  localStorage.setItem('carrinho', JSON.stringify(carrinho));

  const totalItens = carrinho.reduce((sum, p) => sum + p.quantidade, 0);

  alert(`${mensagem}
Total de itens: ${totalItens}`);
}

